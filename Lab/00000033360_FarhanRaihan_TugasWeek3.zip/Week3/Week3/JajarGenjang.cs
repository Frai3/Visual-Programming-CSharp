﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3
{
    class JajarGenjang
    {

        public int alas, tinggi;

        public int Luas(int alas, int tinggi)
        {
            return alas * tinggi;
        }


    }
}
