﻿
namespace Week7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNama = new System.Windows.Forms.TextBox();
            this.txtNamaLengkap = new System.Windows.Forms.TextBox();
            this.txtAlamat = new System.Windows.Forms.TextBox();
            this.txtPanggilan = new System.Windows.Forms.TextBox();
            this.txtUpahTambahan = new System.Windows.Forms.TextBox();
            this.txtUpahJam = new System.Windows.Forms.TextBox();
            this.txtUmur = new System.Windows.Forms.TextBox();
            this.txtUpah = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtJamKerja = new System.Windows.Forms.TextBox();
            this.txtTglLahir = new System.Windows.Forms.DateTimePicker();
            this.comboRole = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtNama
            // 
            this.txtNama.Location = new System.Drawing.Point(162, 21);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(192, 23);
            this.txtNama.TabIndex = 0;
            // 
            // txtNamaLengkap
            // 
            this.txtNamaLengkap.Location = new System.Drawing.Point(162, 63);
            this.txtNamaLengkap.Name = "txtNamaLengkap";
            this.txtNamaLengkap.Size = new System.Drawing.Size(192, 23);
            this.txtNamaLengkap.TabIndex = 1;
            // 
            // txtAlamat
            // 
            this.txtAlamat.Location = new System.Drawing.Point(162, 146);
            this.txtAlamat.Name = "txtAlamat";
            this.txtAlamat.Size = new System.Drawing.Size(192, 23);
            this.txtAlamat.TabIndex = 3;
            // 
            // txtPanggilan
            // 
            this.txtPanggilan.Location = new System.Drawing.Point(162, 104);
            this.txtPanggilan.Name = "txtPanggilan";
            this.txtPanggilan.Size = new System.Drawing.Size(192, 23);
            this.txtPanggilan.TabIndex = 2;
            // 
            // txtUpahTambahan
            // 
            this.txtUpahTambahan.Location = new System.Drawing.Point(162, 312);
            this.txtUpahTambahan.Name = "txtUpahTambahan";
            this.txtUpahTambahan.Size = new System.Drawing.Size(192, 23);
            this.txtUpahTambahan.TabIndex = 7;
            // 
            // txtUpahJam
            // 
            this.txtUpahJam.Location = new System.Drawing.Point(162, 270);
            this.txtUpahJam.Name = "txtUpahJam";
            this.txtUpahJam.Size = new System.Drawing.Size(192, 23);
            this.txtUpahJam.TabIndex = 6;
            // 
            // txtUmur
            // 
            this.txtUmur.Enabled = false;
            this.txtUmur.Location = new System.Drawing.Point(162, 397);
            this.txtUmur.Name = "txtUmur";
            this.txtUmur.Size = new System.Drawing.Size(192, 23);
            this.txtUmur.TabIndex = 9;
            // 
            // txtUpah
            // 
            this.txtUpah.Enabled = false;
            this.txtUpah.Location = new System.Drawing.Point(162, 355);
            this.txtUpah.Name = "txtUpah";
            this.txtUpah.Size = new System.Drawing.Size(192, 23);
            this.txtUpah.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Nama";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "Nama Lengkap";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "Nama Panggilan";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 15);
            this.label4.TabIndex = 13;
            this.label4.Text = "Alamat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "Tgl Lahir";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 232);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "Jam Kerja";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(28, 273);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 15);
            this.label7.TabIndex = 16;
            this.label7.Text = "Upah Per Jam";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 315);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 15);
            this.label8.TabIndex = 17;
            this.label8.Text = "Upah Tambahan";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 358);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 15);
            this.label9.TabIndex = 18;
            this.label9.Text = "Upah yang Diterima";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(28, 400);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 15);
            this.label10.TabIndex = 19;
            this.label10.Text = "Umur";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(85, 489);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(111, 23);
            this.btnSubmit.TabIndex = 20;
            this.btnSubmit.Text = "OK";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(220, 489);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(111, 23);
            this.btnClear.TabIndex = 21;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtJamKerja
            // 
            this.txtJamKerja.Location = new System.Drawing.Point(162, 229);
            this.txtJamKerja.Name = "txtJamKerja";
            this.txtJamKerja.Size = new System.Drawing.Size(192, 23);
            this.txtJamKerja.TabIndex = 5;
            // 
            // txtTglLahir
            // 
            this.txtTglLahir.Location = new System.Drawing.Point(162, 184);
            this.txtTglLahir.Name = "txtTglLahir";
            this.txtTglLahir.Size = new System.Drawing.Size(192, 23);
            this.txtTglLahir.TabIndex = 22;
            this.txtTglLahir.Value = new System.DateTime(2021, 10, 1, 10, 23, 18, 0);
            // 
            // comboRole
            // 
            this.comboRole.FormattingEnabled = true;
            this.comboRole.Items.AddRange(new object[] {
            "Pegawai",
            "Buruh"});
            this.comboRole.Location = new System.Drawing.Point(162, 441);
            this.comboRole.Name = "comboRole";
            this.comboRole.Size = new System.Drawing.Size(192, 23);
            this.comboRole.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(28, 444);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 15);
            this.label11.TabIndex = 24;
            this.label11.Text = "Karyawan";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 532);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.comboRole);
            this.Controls.Add(this.txtTglLahir);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtUmur);
            this.Controls.Add(this.txtUpah);
            this.Controls.Add(this.txtUpahTambahan);
            this.Controls.Add(this.txtUpahJam);
            this.Controls.Add(this.txtJamKerja);
            this.Controls.Add(this.txtAlamat);
            this.Controls.Add(this.txtPanggilan);
            this.Controls.Add(this.txtNamaLengkap);
            this.Controls.Add(this.txtNama);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNama;
        private System.Windows.Forms.TextBox txtNamaLengkap;
        private System.Windows.Forms.TextBox txtAlamat;
        private System.Windows.Forms.TextBox txtPanggilan;
        private System.Windows.Forms.TextBox txtUpahTambahan;
        private System.Windows.Forms.TextBox txtUpahJam;
        private System.Windows.Forms.TextBox txtUmur;
        private System.Windows.Forms.TextBox txtUpah;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtJamKerja;
        private System.Windows.Forms.DateTimePicker txtTglLahir;
        private System.Windows.Forms.ComboBox comboRole;
        private System.Windows.Forms.Label label11;
    }
}

